"""Copies www/index.html into the app and downloads its libraries and fonts so the app works fully offline."""
import hashlib, os, re, urllib.request

SRC = "www/index.html"
OUT = "app/src/main/assets/www"
UA = {"User-Agent": "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"}

os.makedirs(OUT + "/lib", exist_ok=True)
os.makedirs(OUT + "/fonts", exist_ok=True)
html = open(SRC, encoding="utf-8").read()

def get(url):
    return urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=90).read()

for url in re.findall(r'<script src="(https://[^"]+)"', html):
    name = url.split("/")[-1]
    data = get(url)
    open(f"{OUT}/lib/{name}", "wb").write(data)
    html = html.replace(url, "lib/" + name)
    print("library", name, len(data))

m = re.search(r'<link href="(https://fonts\.googleapis\.com/[^"]+)" rel="stylesheet">', html)
if m:
    css = get(m.group(1).replace("&amp;", "&")).decode("utf-8")
    for furl in sorted(set(re.findall(r"url\((https://fonts\.gstatic\.com/[^)]+)\)", css))):
        fname = hashlib.md5(furl.encode()).hexdigest()[:12] + "." + furl.rsplit(".", 1)[-1]
        open(f"{OUT}/fonts/{fname}", "wb").write(get(furl))
        css = css.replace(furl, fname)
    open(f"{OUT}/fonts/fonts.css", "w", encoding="utf-8").write(css)
    html = html.replace(m.group(0), '<link href="fonts/fonts.css" rel="stylesheet">')
    print("fonts ready")

html = re.sub(r'<link rel="preconnect"[^>]*>\s*', "", html)
open(OUT + "/index.html", "w", encoding="utf-8").write(html)
print("app page ready")
